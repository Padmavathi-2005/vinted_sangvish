import React, { createContext, useState, useEffect, useCallback } from 'react';
import axios from '../utils/axios';
import '../i18n';
import { useTranslation } from 'react-i18next';

const LanguageContext = createContext();

export const LanguageProvider = ({ children }) => {
    const [languages, setLanguages] = useState([
        { _id: 'en', name: 'English', code: 'en', native_name: 'English' }
    ]);
    const [currentLanguage, setCurrentLanguage] = useState({ _id: 'en', name: 'English', code: 'en', native_name: 'English' });
    const [defaultLanguage, setDefaultLanguage] = useState(null);
    const { i18n } = useTranslation();

    // Fetch languages and settings exactly once when app loads
    useEffect(() => {
        const fetchInitialData = async () => {
            try {
                const [settingsRes, languagesRes] = await Promise.all([
                    axios.get('/api/settings').catch(() => ({ data: null })),
                    axios.get('/api/languages').catch(() => ({ data: [] }))
                ]);

                let defLanguage = null;
                if (settingsRes.data && settingsRes.data.default_language_id) {
                    defLanguage = settingsRes.data.default_language_id;
                    setDefaultLanguage(defLanguage);
                }

                if (Array.isArray(languagesRes.data)) {
                    setLanguages(languagesRes.data);
                }

                // Check local storage for user's preferred language
                const storedLanguageCode = localStorage.getItem('user_language');

                if (storedLanguageCode && Array.isArray(languagesRes.data)) {
                    const found = languagesRes.data.find(l => l.code === storedLanguageCode);
                    if (found) {
                        setCurrentLanguage(found);
                    } else if (defLanguage) {
                        setCurrentLanguage(defLanguage);
                    }
                } else if (defLanguage) {
                    setCurrentLanguage(defLanguage);
                } else if (Array.isArray(languagesRes.data) && languagesRes.data.length > 0) {
                    setCurrentLanguage(languagesRes.data[0]); // Fallback to first available
                }

            } catch (error) {
                console.error("Failed to fetch language data:", error);
            }
        };

        fetchInitialData();
    }, []);

    const setLanguage = (language) => {
        setCurrentLanguage(language);
        localStorage.setItem('user_language', language.code);

        // update i18next language mapped to our DB code structure
        // 'language.code' mapped to google translate output folder: typically first two chars unless zh-CN
        let i18nCode = language.code;
        if (i18nCode === 'zh') i18nCode = 'zh-CN';
        i18n.changeLanguage(i18nCode);
    };

    // Auto-update i18n when currentLanguage resolves on load
    useEffect(() => {
        if (currentLanguage) {
            let i18nCode = currentLanguage.code;
            if (i18nCode === 'zh') i18nCode = 'zh-CN';
            i18n.changeLanguage(i18nCode);
        }
    }, [currentLanguage, i18n]);

    return (
        <LanguageContext.Provider value={{
            languages,
            currentLanguage,
            setLanguage,
            defaultLanguage
        }}>
            {children}
        </LanguageContext.Provider>
    );
};

export default LanguageContext;
