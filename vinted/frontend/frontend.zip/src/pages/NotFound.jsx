import React from 'react';
import { Container, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';

const NotFound = () => {

    return (
        <Container className="text-center py-5" style={{ minHeight: '60vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
            <h1 className="display-1 fw-bold" style={{ color: 'var(--primary-color, #0ea5e9)' }}>404</h1>
            <h2 className="mb-4">Oops! Page Not Found</h2>
            <p className="text-muted mb-5" style={{ maxWidth: '500px' }}>
                The page you are looking for doesn't exist, has been removed, or is temporarily unavailable.
                Please check the URL or navigate back to the home page.
            </p>
            <Link to="/">
                <Button className="px-5 rounded-pill shadow-sm" style={{ backgroundColor: 'var(--primary-color, #0ea5e9)', border: 'none' }}>
                    Back to Home
                </Button>
            </Link>
        </Container>
    );
};

export default NotFound;
