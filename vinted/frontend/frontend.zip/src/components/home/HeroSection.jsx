import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { FaArrowRight, FaStar, FaUsers } from 'react-icons/fa';
import { useTranslation } from 'react-i18next';

const HeroSection = () => {
    const { t } = useTranslation();
    return (
        <section className="hero-section">
            <Container fluid className="px-md-5 px-3">
                <Row className="align-items-center min-vh-75">
                    <Col lg={9} md={10} className="hero-content">
                        <div className="hero-badge animate-fade-in">
                            {t('home.local_marketplace', 'LOCAL CLASSIFIEDS MARKETPLACE')}
                        </div>
                        <h1 className="hero-title animate-slide-up">
                            {t('home.hero_title').split('from')[0]} <span className="text-primary">from {t('home.hero_title').split('from')[1]}</span>
                        </h1>
                        <p className="hero-subtitle animate-slide-up delay-1">
                            {t('home.hero_subtitle')}
                        </p>
                        <div className="hero-buttons animate-slide-up delay-2">
                            <Link to="/sell">
                                <Button className="btn-hero-primary">
                                    {t('home.start_selling')} <FaArrowRight className="ms-2" />
                                </Button>
                            </Link>
                            <Link to="/products">
                                <Button variant="outline-light" className="btn-hero-secondary">
                                    {t('home.explore_items')}
                                </Button>
                            </Link>
                        </div>
                        <div className="hero-stats animate-fade-in delay-3">
                            <div className="stat-item">
                                <FaStar className="stat-icon" />
                                <div>
                                    <div className="stat-number">4.8/5</div>
                                    <div className="stat-label">{t('home.user_trust_rating', 'User Trust Rating')}</div>
                                </div>
                            </div>
                            <div className="stat-item">
                                <FaUsers className="stat-icon" />
                                <div>
                                    <div className="stat-number">5M+</div>
                                    <div className="stat-label">{t('home.happy_sellers', 'Happy Sellers')}</div>
                                </div>
                            </div>
                        </div>
                    </Col>
                </Row>
            </Container>
        </section>
    );
};

export default HeroSection;
