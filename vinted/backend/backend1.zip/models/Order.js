import mongoose from 'mongoose';

const orderSchema = mongoose.Schema(
    {
        order_number: {
            type: String,
            required: [true, 'Please add an order number'],
            unique: true,
        },
        item_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Item',
            required: true,
        },
        buyer_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        seller_id: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User',
            required: true,
        },
        item_price: {
            type: Number,
            required: true,
        },
        shipping_fee: {
            type: Number,
            default: 0,
        },
        platform_fee: {
            type: Number,
            default: 0,
        },
        total_amount: {
            type: Number,
            required: true,
        },
        payment_method: {
            type: String,
            required: true,
        },
        payment_status: {
            type: String,
            enum: ['pending', 'paid', 'failed', 'refunded', 'partially_refunded'],
            default: 'pending',
        },
        order_status: {
            type: String,
            enum: ['placed', 'dispatched', 'on_the_way', 'delivered', 'cancelled', 'return_requested', 'returned'],
            default: 'placed',
        },
        tracking_number: {
            type: String,
        },
        stripe_payment_id: {
            type: String,
        },
        shipping_address: {
            full_name: String,
            phone: String,
            address_line: String,
            city: String,
            state: String,
            country: String,
            pincode: String,
        },
        delivered_at: {
            type: Date,
        },
        return_reason: {
            type: String,
        },
        partial_refund_reason: {
            type: String,
        },
        refund_amount: {
            type: Number,
            default: 0
        }
    },
    {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'updated_at',
        },
    }
);

export default mongoose.model('Order', orderSchema);
