import mongoose from 'mongoose';

const adminSchema = mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, 'Please add a name'],
        },
        email: {
            type: String,
            required: [true, 'Please add an email'],
            unique: true,
        },
        password_hash: {
            type: String,
            required: [true, 'Please add a password'],
        },
        role: {
            type: String,
            default: 'admin',
        },
        is_active: {
            type: Boolean,
            default: true,
        },
    },
    {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'updated_at',
        },
    }
);

export default mongoose.model('Admin', adminSchema);
