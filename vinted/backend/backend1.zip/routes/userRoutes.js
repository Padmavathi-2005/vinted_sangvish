import express from 'express';
import { protect } from '../middleware/authMiddleware.js';
import upload from '../middleware/profileUpload.js';
const router = express.Router();
import {
    registerUser,
    loginUser,
    getMe,
    deleteAccount,
    updateUserProfile,
    getAllUsers,
    pingActivity,
    getPublicUser,
    updateCookieConsent,
} from '../controllers/userController.js';

router.post('/', registerUser);
router.post('/login', loginUser);
router.get('/me', protect, getMe);
router.get('/', protect, getAllUsers);
router.get('/:id/public', getPublicUser);

router.put('/profile', protect, upload.single('profile_image'), updateUserProfile);
router.patch('/ping', protect, pingActivity);
router.patch('/cookie-consent', protect, updateCookieConsent);
router.delete('/delete', protect, deleteAccount);

export default router;
