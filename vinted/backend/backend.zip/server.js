const express = require('express'); // Restarting for new Stripe Keys

const colors = require('colors');
const dotenv = require('dotenv').config();
const { errorHandler } = require('./middleware/errorMiddleware');
const connectDB = require('./config/db');
const port = process.env.PORT || 5000;
const cors = require('cors');

const startServer = async () => {
    try {
        await connectDB();
        console.log('JWT_SECRET loaded:', process.env.JWT_SECRET ? 'YES (Masked: ' + process.env.JWT_SECRET.substring(0, 3) + '...)' : 'NO (Using fallback)');

        const app = express();

        app.use(cors());
        app.use(express.json());
        app.use((req, res, next) => {
            const logMsg = `[${new Date().toISOString()}] ${req.method} ${req.url} - Auth: ${req.headers.authorization ? req.headers.authorization.substring(0, 20) + '...' : 'MISSING'}\n`;
            require('fs').appendFileSync('auth_errors.log', logMsg);
            console.log(logMsg.trim());
            next();
        });
        const path = require('path');

        app.use(express.urlencoded({ extended: false }));

        // Serve static images from shared folders
        app.use('/images/profile', express.static(path.join(__dirname, '../../vinted-admin/backend/images/profile')));
        app.use('/images/items', express.static(path.join(__dirname, 'images/items'))); // Items uploaded via Vinted app
        app.use('/images/site', express.static(path.join(__dirname, '../../vinted-admin/backend/images/site'))); // Site settings uploaded via Admin


        app.use('/api/items', require('./routes/itemRoutes'));
        app.use('/api/settings', require('./routes/settingRoutes'));
        app.use('/api/users', require('./routes/userRoutes'));
        // app.use('/api/admin', require('./routes/adminRoutes'));
        app.use('/api/categories', require('./routes/categoryRoutes'));
        app.use('/api/favorites', require('./routes/favoriteRoutes'));
        app.use('/api/currencies', require('./routes/currencyRoutes'));
        app.use('/api/languages', require('./routes/languageRoutes'));
        app.use('/api/notifications', require('./routes/notificationRoutes'));
        app.use('/api/messages', require('./routes/messageRoutes'));
        app.use('/api/payments', require('./routes/paymentRoutes'));
        app.use('/api/wallet', require('./routes/walletRoutes'));
        app.use('/api/orders', require('./routes/orderRoutes'));
        app.use('/api/reviews', require('./routes/reviewRoutes'));

        app.use(errorHandler);

        app.listen(port, () => console.log(`Server started on port ${port}`));
    } catch (error) {
        console.error('SERVER FATAL ERROR:', error.message);
        process.exit(1);
    }
};

startServer();
