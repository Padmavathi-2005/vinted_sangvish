const express = require('express');
const router = express.Router();
const { getItems, getItemById, getSimilarItems, getMyItems, setItem, updateItem, deleteItem } = require('../controllers/itemController');
const { protect } = require('../middleware/authMiddleware');
const upload = require('../middleware/uploadMiddleware');

router.route('/').get(getItems).post(protect, upload.array('images', 20), setItem);

router.get('/myitems', protect, getMyItems);
router.get('/:id/similar', getSimilarItems);

router.route('/:id').get(getItemById).put(protect, upload.array('images', 20), updateItem).delete(protect, deleteItem);

module.exports = router;
