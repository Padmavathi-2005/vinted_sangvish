const express = require('express');
const router = express.Router();
const {
    getCategories,
    getFullCategoryTree,
    getCategoryBySlug,
    getSubcategoryBySlug,
    createCategory,
    createSubcategory,
    createItemType
} = require('../controllers/categoryController');

// POST /api/categories/subcategories
router.post('/subcategories', createSubcategory);

// POST /api/categories/itemtypes
router.post('/itemtypes', createItemType);

// POST /api/categories
router.post('/', createCategory);

// GET /api/categories              → all top-level categories
router.get('/', getCategories);

// GET /api/categories/full         → full tree for mega-menu
router.get('/full', getFullCategoryTree);

// GET /api/categories/:slug        → single category + subcategories
router.get('/:slug', getCategoryBySlug);

// GET /api/categories/:categorySlug/:subcategorySlug
router.get('/:categorySlug/:subcategorySlug', getSubcategoryBySlug);

module.exports = router;
