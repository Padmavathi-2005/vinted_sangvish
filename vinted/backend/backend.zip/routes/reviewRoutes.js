const express = require('express');
const router = express.Router();
const { createReview, getUserReviews, getOrderReview } = require('../controllers/reviewController');
const { protect } = require('../middleware/authMiddleware');

router.post('/', protect, createReview);
router.get('/user/:userId', getUserReviews);
router.get('/order/:orderId', protect, getOrderReview);

module.exports = router;
