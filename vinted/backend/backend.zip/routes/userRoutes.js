const express = require('express');
const router = express.Router();
const {
    registerUser,
    loginUser,
    getMe,
    deleteAccount,
    updateUserProfile,
    getAllUsers,
    pingActivity,
    getPublicUser,
} = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');

router.post('/', registerUser);
router.post('/login', loginUser);
router.get('/me', protect, getMe);
router.get('/', protect, getAllUsers);
router.get('/:id/public', getPublicUser);
const upload = require('../middleware/profileUpload');

router.put('/profile', protect, upload.single('profile_image'), updateUserProfile);
router.patch('/ping', protect, pingActivity);
router.delete('/delete', protect, deleteAccount);

module.exports = router;
