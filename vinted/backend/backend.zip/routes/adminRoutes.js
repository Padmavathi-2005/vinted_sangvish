const express = require('express');
const router = express.Router();
const {
    loginAdmin,
    getDashboardStats,
    getUsers,
    createUser,
    updateUser,
    deleteUser,
    verifyAdmin
} = require('../controllers/adminController');
const { adminProtect } = require('../middleware/authMiddleware');

router.post('/login', loginAdmin);

// Protected Admin Routes
router.use(adminProtect);

router.get('/verify', verifyAdmin);
router.get('/dashboard', getDashboardStats);

// User Management
router.get('/users', getUsers);
router.post('/users', createUser);
router.put('/users/:id', updateUser);
router.delete('/users/:id', deleteUser);

module.exports = router;
