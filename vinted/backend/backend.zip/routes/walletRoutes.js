const express = require('express');
const router = express.Router();
const { getMyWallet } = require('../controllers/walletController');
const { requestWithdrawal, getMyWithdrawals } = require('../controllers/withdrawalController');
const { protect } = require('../middleware/authMiddleware');

router.get('/me', protect, getMyWallet);
router.post('/withdraw', protect, requestWithdrawal);
router.get('/withdrawals', protect, getMyWithdrawals);

module.exports = router;
