const express = require('express');
const router = express.Router();
const { createOrder, getMyOrders, updateOrderAddress, updateOrderStatus, cancelOrder } = require('../controllers/orderController');
const { protect } = require('../middleware/authMiddleware');

router.post('/', protect, createOrder);
router.get('/', protect, getMyOrders);
router.put('/:id/address', protect, updateOrderAddress);
router.put('/:id/status', protect, updateOrderStatus);
router.post('/:id/cancel', protect, cancelOrder);

module.exports = router;
