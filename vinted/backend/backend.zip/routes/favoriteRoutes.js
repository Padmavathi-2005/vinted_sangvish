const express = require('express');
const router = express.Router();
const {
    getMyFavorites,
    addToFavorites,
    removeFromFavorites
} = require('../controllers/favoriteController');
const { protect } = require('../middleware/authMiddleware');

router.get('/', protect, getMyFavorites);
router.post('/', protect, addToFavorites);
router.delete('/:itemId', protect, removeFromFavorites);

module.exports = router;
