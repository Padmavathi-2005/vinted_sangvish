const express = require('express');
const router = express.Router();
const { getPaymentMethods, createStripeIntent } = require('../controllers/paymentController');
const { protect } = require('../middleware/authMiddleware');

router.get('/methods', getPaymentMethods);
router.post('/stripe/create-intent', protect, createStripeIntent);

module.exports = router;
