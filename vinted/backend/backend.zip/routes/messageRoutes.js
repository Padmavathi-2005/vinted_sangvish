const express = require('express');
const router = express.Router();
const {
    getConversations,
    getMessages,
    sendMessage,
    respondToRequest,
    toggleBlock,
} = require('../controllers/messageController');
const { protect } = require('../middleware/authMiddleware');

router.use(protect);

router.get('/conversations', getConversations);
router.get('/:id', getMessages);
router.post('/', sendMessage);
router.patch('/respond/:id', respondToRequest);
router.patch('/block/:id', toggleBlock);

module.exports = router;
