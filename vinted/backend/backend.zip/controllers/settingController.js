const asyncHandler = require('express-async-handler');
const Setting = require('../models/Setting');

// @desc    Get global settings or initialize defaults
// @route   GET /api/settings
// @access  Public
const getSettings = asyncHandler(async (req, res) => {
    try {
        const generalSettings = await Setting.findOne({ type: 'general_settings' }).populate('default_currency_id default_language_id');
        const siteSettings = await Setting.findOne({ type: 'site_settings' });

        let mergedSettings = {};
        if (generalSettings) mergedSettings = { ...mergedSettings, ...generalSettings.toObject() };
        if (siteSettings) mergedSettings = { ...mergedSettings, ...siteSettings.toObject() };

        if (!generalSettings && !siteSettings) {
            mergedSettings = {
                site_name: 'My Marketplace',
                primary_color: '#0ea5e9',
                pagination_limit: 12
            };
        }
        res.json(mergedSettings);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// @desc    Update settings
// @route   PUT /api/settings
// @access  Protected (Simplified here)
const updateSettings = asyncHandler(async (req, res) => {
    let setting = await Setting.findOne();

    if (setting) {
        // Dynamic update from body
        Object.assign(setting, req.body);
        const updatedSetting = await setting.save();
        res.json(updatedSetting);
    } else {
        const newSetting = await Setting.create(req.body);
        res.status(201).json(newSetting);
    }
});

module.exports = {
    getSettings,
    updateSettings,
};
