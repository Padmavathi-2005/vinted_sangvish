const asyncHandler = require('express-async-handler');
const Wallet = require('../models/Wallet');
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const Admin = require('../models/Admin');
const Setting = require('../models/Setting');
const mongoose = require('mongoose');

// Helper to get or create wallet
const getOrCreateWallet = async (ownerId, ownerType) => {
    let wallet = await Wallet.findOne({ owner_id: ownerId, owner_type: ownerType });
    if (!wallet) {
        wallet = await Wallet.create({
            owner_id: ownerId,
            owner_type: ownerType,
            balance: 0
        });
    }
    return wallet;
};

// @desc    Process order payment split (Admin 2%, Seller 98%)
// This should be called after a successful paymnet
// @desc    Process order payment split (Admin 2% of item price, Seller 98% of item price + shipping)
const processOrderPaymentSplit = async (orderData) => {
    const { seller_id, item_price, shipping_fee, order_id } = orderData;

    const settings = await Setting.findOne();
    const commissionRate = settings?.admin_commission || 2; // Default 2%

    const adminCommission = (item_price * commissionRate) / 100;
    const sellerEarning = (item_price - adminCommission) + shipping_fee;

    // 1. Credit Admin Wallet
    const admin = await Admin.findOne({ is_active: true });
    if (admin) {
        const adminWallet = await getOrCreateWallet(admin._id, 'Admin');
        adminWallet.balance += adminCommission;
        await adminWallet.save();

        await Transaction.create({
            user_id: admin._id,
            user_type: 'Admin',
            wallet_id: adminWallet._id,
            amount: adminCommission,
            type: 'credit',
            purpose: 'commission',
            reference_id: order_id,
            reference_model: 'Order',
            description: `Commission from order #${order_id}`
        });
    }

    // 2. Credit Seller Wallet
    const sellerWallet = await getOrCreateWallet(seller_id, 'User');
    sellerWallet.balance += sellerEarning;
    await sellerWallet.save();

    await User.findByIdAndUpdate(seller_id, { $inc: { balance: sellerEarning } });

    await Transaction.create({
        user_id: seller_id,
        user_type: 'User',
        wallet_id: sellerWallet._id,
        amount: sellerEarning,
        type: 'credit',
        purpose: 'sale_earning',
        reference_id: order_id,
        reference_model: 'Order',
        description: `Earning from order #${order_id} (Net: ${item_price - adminCommission} + Shipping: ${shipping_fee})`
    });

    return { adminCommission, sellerEarning };
};

// @desc    Get user wallet and transactions
// @route   GET /api/wallet/me
// @access  Private
const getMyWallet = asyncHandler(async (req, res) => {
    const wallet = await getOrCreateWallet(req.user._id, 'User');
    const transactions = await Transaction.find({ wallet_id: wallet._id }).sort({ created_at: -1 });

    res.json({
        wallet,
        transactions
    });
});

// @desc    Reverse payment for a cancelled order (Clawback from seller/admin, refund to buyer)
const reverseOrderPayment = async (orderId) => {
    const Order = require('../models/Order'); // Local import to avoid circular dependency
    const order = await Order.findById(orderId);
    if (!order || order.payment_status !== 'paid') return;

    const { seller_id, buyer_id, item_price, shipping_fee } = order;

    // Recalculate split
    const settings = await Setting.findOne();
    const commissionRate = settings?.admin_commission || 2;
    const adminCommission = (item_price * commissionRate) / 100;
    const sellerEarning = (item_price - adminCommission) + shipping_fee;
    const fullRefundAmount = item_price + shipping_fee;

    // 1. Debit Admin Wallet (take back commission)
    const admin = await Admin.findOne({ is_active: true });
    if (admin) {
        const adminWallet = await getOrCreateWallet(admin._id, 'Admin');
        adminWallet.balance -= adminCommission;
        await adminWallet.save();

        await Transaction.create({
            user_id: admin._id,
            user_type: 'Admin',
            wallet_id: adminWallet._id,
            amount: adminCommission,
            type: 'debit',
            purpose: 'order_refund',
            reference_id: orderId,
            reference_model: 'Order',
            description: `Commission reversal for cancelled order #${order.order_number}`
        });
    }

    // 2. Debit Seller Wallet (take back earning)
    const sellerWallet = await getOrCreateWallet(seller_id, 'User');
    sellerWallet.balance -= sellerEarning;
    await sellerWallet.save();

    await Transaction.create({
        user_id: seller_id,
        user_type: 'User',
        wallet_id: sellerWallet._id,
        amount: sellerEarning,
        type: 'debit',
        purpose: 'order_refund',
        reference_id: orderId,
        reference_model: 'Order',
        description: `Earning reversal for cancelled order #${order.order_number}`
    });

    // 3. Credit Buyer Wallet (full refund)
    const buyerWallet = await getOrCreateWallet(buyer_id, 'User');
    buyerWallet.balance += fullRefundAmount;
    await buyerWallet.save();

    await Transaction.create({
        user_id: buyer_id,
        user_type: 'User',
        wallet_id: buyerWallet._id,
        amount: fullRefundAmount,
        type: 'credit',
        purpose: 'order_refund',
        reference_id: orderId,
        reference_model: 'Order',
        description: `Full refund for cancelled order #${order.order_number}`
    });
};

module.exports = {
    getMyWallet,
    processOrderPaymentSplit,
    reverseOrderPayment,
    getOrCreateWallet
};
