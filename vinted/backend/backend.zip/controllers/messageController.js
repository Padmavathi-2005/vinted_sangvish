const asyncHandler = require('express-async-handler');
const Message = require('../models/Message');
const Conversation = require('../models/Conversation');
const Notification = require('../models/Notification');
const User = require('../models/User');

// @desc    Get all conversations for user
// @route   GET /api/messages/conversations
// @access  Private
const getConversations = asyncHandler(async (req, res) => {
    const conversations = await Conversation.find({
        participants: { $in: [req.user.id] },
    })
        .populate('participants', 'name username profile_image last_login')
        .populate('item_id', 'title price images')
        .populate('initiator_id', '_id')
        .sort({ last_message_at: -1 });

    res.status(200).json(conversations);
});

// @desc    Get messages for a conversation
// @route   GET /api/messages/:id
// @access  Private
const getMessages = asyncHandler(async (req, res) => {
    const conversation = await Conversation.findById(req.params.id)
        .populate('participants', 'username profile_image last_login')
        .populate('initiator_id', '_id');

    if (!conversation) {
        res.status(404);
        throw new Error('Conversation not found');
    }

    const isParticipant = conversation.participants.some(p => p._id.toString() === req.user.id);
    if (!isParticipant) {
        res.status(401);
        throw new Error('User not authorized');
    }

    const messages = await Message.find({ conversation_id: req.params.id })
        .sort({ created_at: 1 });

    res.status(200).json({
        conversation,
        messages
    });
});

// @desc    Send a message
// @route   POST /api/messages
// @access  Private
const sendMessage = asyncHandler(async (req, res) => {
    const { receiver_id, message, item_id } = req.body;

    if (!receiver_id || !message) {
        res.status(400);
        throw new Error('Please add receiver and message');
    }

    // Find if conversation already exists
    let conversation = await Conversation.findOne({
        participants: { $all: [req.user.id, receiver_id] },
    });

    let isNewRequest = false;

    if (!conversation) {
        conversation = await Conversation.create({
            participants: [req.user.id, receiver_id],
            item_id: item_id,
            status: 'pending',
            initiator_id: req.user.id,
            last_message: message,
            last_message_at: Date.now(),
        });
        isNewRequest = true;
    } else {
        if (conversation.blocked_by && conversation.blocked_by.length > 0) {
            res.status(403);
            throw new Error('This conversation is blocked.');
        }

        // If rejected, no one can send (only recipient can accept via respond endpoint)
        if (conversation.status === 'rejected') {
            res.status(403);
            throw new Error('This message request was declined. The recipient can accept it if they change their mind.');
        }

        conversation.last_message = message;
        conversation.last_message_at = Date.now();
        await conversation.save();
    }

    const newMessage = await Message.create({
        conversation_id: conversation._id,
        sender_id: req.user.id,
        receiver_id: receiver_id,
        message: message,
    });

    if (isNewRequest) {
        await Notification.create({
            user_id: receiver_id,
            title: 'New Message Request',
            message: `${req.user.username} wants to start a conversation with you.`,
            type: 'request',
            link: `/profile?tab=messages&conversation=${conversation._id}`,
        });
    } else if (conversation.status === 'accepted') {
        await Notification.create({
            user_id: receiver_id,
            title: 'New Message',
            message: `You have a new message from ${req.user.username}`,
            type: 'message',
            link: `/profile?tab=messages&conversation=${conversation._id}`,
        });
    }

    // Return with updated conversation so frontend can reflect re-request
    res.status(201).json({ message: newMessage, conversation });
});

// @desc    Respond to message request (accept or reject, can be changed any time by recipient)
// @route   PATCH /api/messages/respond/:id
// @access  Private
const respondToRequest = asyncHandler(async (req, res) => {
    const { status } = req.body; // 'accepted' or 'rejected'

    if (!['accepted', 'rejected'].includes(status)) {
        res.status(400);
        throw new Error('Invalid status');
    }

    const conversation = await Conversation.findById(req.params.id)
        .populate('participants', 'username profile_image last_login');

    if (!conversation) {
        res.status(404);
        throw new Error('Conversation not found');
    }

    // Only the recipient (not the initiator) can respond
    if (conversation.initiator_id.toString() === req.user.id) {
        res.status(401);
        throw new Error('Only the recipient can respond to the request');
    }

    const isParticipant = conversation.participants.some(p => p._id.toString() === req.user.id);
    if (!isParticipant) {
        res.status(401);
        throw new Error('User not authorized');
    }

    const previousStatus = conversation.status;
    conversation.status = status;
    await conversation.save();

    // Notify the initiator about the status change
    const initiatorId = conversation.initiator_id;

    if (status === 'accepted') {
        await Notification.create({
            user_id: initiatorId,
            title: 'Message Request Accepted',
            message: `${req.user.username} accepted your message request. You can now chat!`,
            type: 'success',
            link: `/profile?tab=messages&conversation=${conversation._id}`,
        });
    } else if (status === 'rejected') {
        await Notification.create({
            user_id: initiatorId,
            title: 'Message Request Rejected',
            message: `${req.user.username} declined your message request.`,
            type: 'error',
            link: `/profile?tab=messages&conversation=${conversation._id}`,
        });
    }

    res.status(200).json(conversation);
});

// @desc    Toggle block status of a conversation
// @route   PATCH /api/messages/block/:id
// @access  Private
const toggleBlock = asyncHandler(async (req, res) => {
    const conversation = await Conversation.findById(req.params.id);

    if (!conversation) {
        res.status(404);
        throw new Error('Conversation not found');
    }

    if (!conversation.participants.includes(req.user.id)) {
        res.status(401);
        throw new Error('User not authorized');
    }

    const index = conversation.blocked_by.indexOf(req.user.id);
    if (index === -1) {
        conversation.blocked_by.push(req.user.id);
    } else {
        conversation.blocked_by.splice(index, 1);
    }

    await conversation.save();
    res.status(200).json(conversation);
});

module.exports = {
    getConversations,
    getMessages,
    sendMessage,
    respondToRequest,
    toggleBlock,
};
