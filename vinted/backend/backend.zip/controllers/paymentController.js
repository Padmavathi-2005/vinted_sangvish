const asyncHandler = require('express-async-handler');
const PaymentMethod = require('../models/PaymentMethod');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

if (!process.env.STRIPE_SECRET_KEY) {
    console.error('CRITICAL: STRIPE_SECRET_KEY is missing from .env file');
}


// @desc    Get all enabled payment methods
// @route   GET /api/payment-methods
// @access  Public
const getPaymentMethods = asyncHandler(async (req, res) => {
    const methods = await PaymentMethod.find({ is_active: true }).sort('sort_order');
    res.json(methods);
});

// @desc    Create Stripe Payment Intent
// @route   POST /api/payment/stripe/create-intent
// @access  Private
const createStripeIntent = asyncHandler(async (req, res) => {
    const { amount, currency } = req.body;
    console.log('Stripe Intent Request:', { amount, currency });

    if (!amount || isNaN(amount)) {
        res.status(400);
        throw new Error('Valid amount is required');
    }

    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount: Math.round(amount * 100), // convert to cents
            currency: currency || 'inr',
            description: `Order for User: ${req.user?._id || 'Guest'} - ${req.user?.email || ''}`,
            automatic_payment_methods: {
                enabled: true,
            },
        });

        res.json({
            clientSecret: paymentIntent.client_secret,
        });
    } catch (error) {
        console.error('Stripe Error:', error.message);
        // Use 400 Bad Request for payment initialization errors to avoid auto-logout trigger (which often listens for 401/500 specifically)
        // or just ensure it's not 401.
        res.status(400).json({
            message: error.message || 'Payment provider error',
            type: error.type
        });
    }
});

module.exports = {
    getPaymentMethods,
    createStripeIntent
};
