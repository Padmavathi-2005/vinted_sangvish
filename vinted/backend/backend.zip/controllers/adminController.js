const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const asyncHandler = require('express-async-handler');
const Admin = require('../models/Admin');
const User = require('../models/User');

// @desc    Admin Login
// @route   POST /api/admin/login
// @access  Public
const loginAdmin = asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    // Check for admin in the separate Admin collection
    const admin = await Admin.findOne({ email: email.toLowerCase() });

    console.log(`Login attempt for: ${email}`);
    if (admin) {
        console.log(`Admin found for: ${email}`);
    } else {
        console.log(`Admin NOT found for: ${email}`);
    }

    if (admin && (await bcrypt.compare(password, admin.password_hash))) {
        res.json({
            _id: admin.id,
            name: admin.name,
            email: admin.email,
            token: generateToken(admin._id),
            role: 'admin'
        });
    } else {
        res.status(400);
        throw new Error('Invalid Admin credentials');
    }
});

// @desc    Get dashboard stats
// @route   GET /api/admin/dashboard
// @access  Private (Admin)
const getDashboardStats = asyncHandler(async (req, res) => {
    // Stats for users from the User collection
    const totalUsers = await User.countDocuments();
    res.json({
        totalUsers,
    });
});

// @desc    Get all users
// @route   GET /api/admin/users
// @access  Private (Admin)
const getUsers = asyncHandler(async (req, res) => {
    const users = await User.find({}).sort({ created_at: -1 });
    res.json(users);
});

// @desc    Create a user
// @route   POST /api/admin/users
// @access  Private (Admin)
const createUser = asyncHandler(async (req, res) => {
    const { username, email, password, status } = req.body;

    const userExists = await User.findOne({ email });
    if (userExists) {
        res.status(400);
        throw new Error('User already exists');
    }

    const user = await User.create({
        username,
        email,
        password_hash: password,
        is_blocked: status === 'Inactive' || status === 'Banned'
    });

    if (user) {
        res.status(201).json(user);
    } else {
        res.status(400);
        throw new Error('Invalid user data');
    }
});

// @desc    Update a user
// @route   PUT /api/admin/users/:id
// @access  Private (Admin)
const updateUser = asyncHandler(async (req, res) => {
    const { username, email, status, password } = req.body;
    const user = await User.findById(req.params.id);

    if (!user) {
        res.status(404);
        throw new Error('User not found');
    }

    user.username = username || user.username;
    user.email = email || user.email;

    if (status !== undefined) {
        user.is_blocked = (status === 'Inactive' || status === 'Banned' || status === false);
    }

    if (password) {
        user.password_hash = password;
    }

    const updatedUser = await user.save();
    res.json(updatedUser);
});

// @desc    Delete a user
// @route   DELETE /api/admin/users/:id
// @access  Private (Admin)
const deleteUser = asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id);
    if (!user) {
        res.status(404);
        throw new Error('User not found');
    }

    await user.remove();
    res.json({ message: 'User deleted' });
});

// @desc    Verify admin token
// @route   GET /api/admin/verify
// @access  Private (Admin)
const verifyAdmin = asyncHandler(async (req, res) => {
    // If they reached here, adminProtect passed
    res.json({
        success: true,
        admin: {
            _id: req.user._id,
            name: req.user.name,
            email: req.user.email,
            role: 'admin'
        }
    });
});

const generateToken = (id) => {
    const secret = process.env.JWT_SECRET || 'secret123';
    console.log('Generating token with secret:', secret === 'secret123' ? 'FALLBACK' : 'CUSTOM');

    // Ensure id is a string for the JWT payload
    return jwt.sign({ id: id.toString(), role: 'admin' }, secret, {
        expiresIn: '30d',
    });
};

module.exports = {
    loginAdmin,
    getDashboardStats,
    getUsers,
    createUser,
    updateUser,
    deleteUser,
    verifyAdmin
};
