const mongoose = require('mongoose');

const paymentMethodSchema = mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, 'Please add a name'],
        },
        key: {
            type: String,
            required: [true, 'Please add a key'],
            unique: true,
        },
        description: {
            type: String,
        },
        icon: {
            type: String,
        },
        is_active: {
            type: Boolean,
            default: true,
        },
        sort_order: {
            type: Number,
            default: 0,
        },
    },
    {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'updated_at',
        },
    }
);

module.exports = mongoose.model('PaymentMethod', paymentMethodSchema);
