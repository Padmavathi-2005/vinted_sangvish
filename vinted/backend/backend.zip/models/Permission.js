const mongoose = require('mongoose');

const permissionSchema = mongoose.Schema(
    {
        name: {
            type: String,
            required: [true, 'Please add a permission name'],
            unique: true,
        },
        description: {
            type: String,
        },
        module: {
            type: String,
            required: [true, 'Please add a module name'],
        },
    },
    {
        timestamps: {
            createdAt: 'created_at',
            updatedAt: 'updated_at',
        },
    }
);

module.exports = mongoose.model('Permission', permissionSchema);
