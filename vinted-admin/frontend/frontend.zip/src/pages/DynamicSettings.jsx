import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Form, Button, Row, Col, Card, InputGroup, Container } from 'react-bootstrap';
import { FaCloudUploadAlt, FaSave, FaUndo, FaImage } from 'react-icons/fa';
import { useSettings } from '../context/SettingsContext';
import axios from '../utils/axios';
import AdminSearchSelect from '../components/AdminSearchSelect';
import Toggle from '../components/Toggle';
import { showToast } from '../utils/swal';
import '../styles/Settings.css';

const DynamicSettings = () => {
    const { type } = useParams();
    const { getSettingsByType, updateSettingsByType } = useSettings();

    const [formData, setFormData] = useState({});
    const [previews, setPreviews] = useState({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);

    const [languages, setLanguages] = useState([]);
    const [currencies, setCurrencies] = useState([]);

    useEffect(() => {
        fetchData();
    }, [type]);

    const fetchData = async () => {
        setLoading(true);
        try {
            const [settingsData, langRes, currRes] = await Promise.all([
                getSettingsByType(type),
                axios.get('/api/admin/languages'),
                axios.get('/api/admin/currencies')
            ]);

            if (settingsData) {
                setFormData(settingsData);
                // Initialize previews if logo exists
                if (settingsData.site_logo) setPreviews(prev => ({ ...prev, site_logo: `${axios.defaults.baseURL}/${settingsData.site_logo}` }));
                if (settingsData.site_favicon) setPreviews(prev => ({ ...prev, site_favicon: `${axios.defaults.baseURL}/${settingsData.site_favicon}` }));
                if (settingsData.image_not_found) setPreviews(prev => ({ ...prev, image_not_found: `${axios.defaults.baseURL}/${settingsData.image_not_found}` }));
                if (settingsData.empty_table_image) setPreviews(prev => ({ ...prev, empty_table_image: `${axios.defaults.baseURL}/${settingsData.empty_table_image}` }));
            }
            setLanguages(langRes.data);
            setCurrencies(currRes.data);
        } catch (error) {
            console.error("Error fetching settings data", error);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value, type, checked } = e.target;

        if (type === 'number') {
            const num = parseFloat(value);
            if (num <= 0) return; // Ignore zero or negative
        }

        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value
        }));
    };

    const handleFileChange = (e) => {
        const file = e.target.files[0];
        const name = e.target.name;
        if (file) {
            setFormData(prev => ({ ...prev, [name]: file }));
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviews(prev => ({ ...prev, [name]: reader.result }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setSaving(true);

        const data = new FormData();
        const skipFields = ['_id', '__v', 'created_at', 'updated_at', 'type', 'general_settings', 'admin_settings'];

        Object.keys(formData).forEach(key => {
            if (!skipFields.includes(key) && formData[key] !== null && formData[key] !== undefined) {
                const value = formData[key];

                // If it's a file, keep as is.
                if (value instanceof File) {
                    data.append(key, value);
                } else if (typeof value === 'object' && value !== null) {
                    // If it's a reference object with _id, send the ID.
                    if (value._id) {
                        data.append(key, value._id);
                    }
                } else {
                    data.append(key, value);
                }
            }
        });

        const result = await updateSettingsByType(type, data);
        if (result.success) {
            showToast('success', 'Settings updated successfully!');
        } else {
            showToast('error', 'Error updating settings');
        }
        setSaving(false);
    };

    if (loading) return <div className="p-4 text-center">Loading settings...</div>;

    const renderField = (key, value) => {
        // Skip internal/legacy fields
        if (['_id', '__v', 'created_at', 'updated_at', 'type', 'admin_settings', 'general_settings', 'pagination_mode'].includes(key)) return null;

        const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

        if (['site_logo', 'site_favicon', 'image_not_found', 'empty_table_image'].includes(key)) {
            return (
                <Col key={key} md={12} className="mb-4">
                    <Form.Label className="fw-bold">{label}</Form.Label>
                    <div className="upload-container">
                        <input
                            type="file"
                            name={key}
                            id={key}
                            className="file-input"
                            onChange={handleFileChange}
                            accept="image/*"
                        />
                        <label htmlFor={key} className="upload-label">
                            <div className="preview-area">
                                {previews[key] ? (
                                    <img src={previews[key]} alt="Preview" className="img-preview" />
                                ) : (
                                    <div className="placeholder-preview">
                                        <FaCloudUploadAlt size={40} className="mb-2" />
                                        <span>Click to upload or drag & drop</span>
                                    </div>
                                )}
                            </div>
                        </label>
                    </div>
                </Col>
            );
        }

        if (typeof value === 'boolean') {
            return (
                <Col key={key} md={6} className="mb-4 d-flex justify-content-start flex-column">
                    <Form.Group className="d-flex flex-column h-100 pb-2">
                        {/* Invisible label for spacing consistency with neighbor inputs */}
                        <Form.Label className="invisible mb-2">{label}</Form.Label>
                        <div className="mt-auto">
                            <Toggle
                                label={label}
                                checked={formData[key] || false}
                                onChange={(checked) => setFormData(prev => ({ ...prev, [key]: checked }))}
                            />
                        </div>
                    </Form.Group>
                </Col>
            );
        }

        if (key.includes('color')) {
            return (
                <Col key={key} md={6} className="mb-4">
                    <Form.Group>
                        <Form.Label className="mb-2">{label}</Form.Label>
                        <div className="d-flex gap-3 align-items-center">
                            <div className="color-picker-wrapper">
                                <Form.Control
                                    type="color"
                                    name={key}
                                    value={formData[key] || '#000000'}
                                    onChange={handleInputChange}
                                    className="color-picker"
                                />
                            </div>
                            <Form.Control
                                type="text"
                                name={key}
                                value={formData[key] || '#000000'}
                                onChange={handleInputChange}
                                className="color-input-field"
                                style={{ maxWidth: '150px' }}
                            />
                        </div>
                    </Form.Group>
                </Col>
            );
        }

        if (key === 'admin_commission') {
            return (
                <Col key={key} md={6} className="mb-4">
                    <Form.Group>
                        <Form.Label className="mb-2">{label}</Form.Label>
                        <InputGroup>
                            <Form.Control
                                type="number"
                                name={key}
                                value={formData[key] || 0}
                                onChange={handleInputChange}
                            />
                            <InputGroup.Text className="bg-light fw-bold text-muted">%</InputGroup.Text>
                        </InputGroup>
                    </Form.Group>
                </Col>
            );
        }

        if (key === 'default_language_id') {
            return (
                <Col key={key} md={6} className="mb-4">
                    <Form.Group>
                        <Form.Label className="mb-2">{label}</Form.Label>
                        <AdminSearchSelect
                            options={languages.map(lang => ({ value: lang._id, label: lang.name }))}
                            value={formData[key] || ''}
                            onChange={(val) => setFormData({ ...formData, [key]: val })}
                            placeholder="Select Default Language..."
                        />
                    </Form.Group>
                </Col>
            );
        }

        if (key === 'default_currency_id') {
            return (
                <Col key={key} md={6} className="mb-4">
                    <Form.Group>
                        <Form.Label className="mb-2">{label}</Form.Label>
                        <AdminSearchSelect
                            options={currencies.map(curr => ({ value: curr._id, label: `${curr.name} (${curr.code})` }))}
                            value={formData[key] || ''}
                            onChange={(val) => setFormData({ ...formData, [key]: val })}
                            placeholder="Select Default Currency..."
                        />
                    </Form.Group>
                </Col>
            );
        }

        if (typeof value === 'number') {
            return (
                <Col key={key} md={6} className="mb-3">
                    <Form.Group>
                        <Form.Label>{label}</Form.Label>
                        <Form.Control
                            type="number"
                            name={key}
                            value={formData[key] || 0}
                            onChange={handleInputChange}
                        />
                    </Form.Group>
                </Col>
            );
        }

        return (
            <Col key={key} md={6} className="mb-3">
                <Form.Group>
                    <Form.Label>{label}</Form.Label>
                    <Form.Control
                        type="text"
                        name={key}
                        value={formData[key] || ''}
                        onChange={handleInputChange}
                    />
                </Form.Group>
            </Col>
        );
    };

    return (
        <div className="admin-dashboard">
            <div className="dashboard-header mb-4">
                <div className="d-flex align-items-center gap-3">
                    <h2 className="dashboard-title text-capitalize">{type.replace(/_/g, ' ')}</h2>
                </div>
                <div className="d-flex gap-2">
                    <Button
                        variant="outline-secondary"
                        className="btn-admin-outline"
                        onClick={fetchData}
                        disabled={saving}
                    >
                        <FaUndo /> Reset
                    </Button>
                    <Button
                        variant="primary"
                        className="btn-admin-action"
                        onClick={handleSubmit}
                        disabled={saving}
                    >
                        <FaSave /> {saving ? 'Saving...' : 'Save Changes'}
                    </Button>
                </div>
            </div>

            <Container fluid className="px-0">
                <Card className="main-content-card border-0 shadow-sm p-4">
                    <Form onSubmit={handleSubmit}>
                        <Row>
                            {/* Images explicitly rendered first */}
                            {['site_logo', 'site_favicon', 'image_not_found', 'empty_table_image'].filter(k => formData[k] !== undefined).map(k => renderField(k, formData[k]))}

                            {/* Other fields sorted by type/custom order */}
                            {Object.entries(formData)
                                .filter(([k]) => !['site_logo', 'site_favicon', 'image_not_found', 'empty_table_image'].includes(k))
                                .sort((a, b) => {
                                    const aOrder = typeof a[1] === 'boolean' ? 1 : 0;
                                    const bOrder = typeof b[1] === 'boolean' ? 1 : 0;
                                    return aOrder - bOrder;
                                })
                                .map(([key, value]) => renderField(key, value))
                            }
                        </Row>

                        <div className="mt-5 pt-4 border-top d-flex justify-content-end gap-3">
                            <Button
                                type="submit"
                                variant="primary"
                                className="btn-admin-action"
                                disabled={saving}
                            >
                                <FaSave /> {saving ? 'Saving...' : 'Save All Changes'}
                            </Button>
                        </div>
                    </Form>
                </Card>
            </Container>
        </div>
    );
};

export default DynamicSettings;
