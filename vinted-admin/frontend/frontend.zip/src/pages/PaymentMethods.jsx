import React, { useState, useEffect } from 'react';
import { Container, Button, Card, Form, InputGroup, Spinner, Row, Col } from 'react-bootstrap';
import { FaPlus, FaSearch, FaTrash, FaEdit, FaCreditCard } from 'react-icons/fa';
import Table from '../components/Table';
import Modal from '../components/Modal';
import Toggle from '../components/Toggle';
import axios from '../utils/axios';
import { showToast, showConfirm } from '../utils/swal';

const PaymentMethods = () => {
    const [methods, setMethods] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [selectedMethod, setSelectedMethod] = useState(null);
    const [formData, setFormData] = useState({
        name: '',
        key: '',
        description: '',
        is_active: true,
        sort_order: 0
    });
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        fetchMethods();
    }, []);

    const fetchMethods = async () => {
        try {
            setLoading(true);
            const { data } = await axios.get('/api/admin/payment-methods');
            setMethods(data);
        } catch (error) {
            console.error('Error fetching methods:', error);
            showToast('error', 'Failed to load payment methods');
        } finally {
            setLoading(false);
        }
    };

    const handleSave = async () => {
        if (!formData.name || !formData.key) {
            showToast('error', 'Name and Key are required');
            return;
        }

        try {
            setSaving(true);
            const methodData = {
                ...formData,
                sort_order: parseInt(formData.sort_order) || 0
            };

            if (selectedMethod) {
                await axios.put(`/api/admin/payment-methods/${selectedMethod._id}`, methodData);
                showToast('success', 'Payment method updated');
            } else {
                await axios.post('/api/admin/payment-methods', methodData);
                showToast('success', 'Payment method created');
            }
            setShowModal(false);
            fetchMethods();
        } catch (error) {
            showToast('error', error.response?.data?.message || 'Failed to save payment method');
        } finally {
            setSaving(false);
        }
    };

    const handleEdit = (method) => {
        setSelectedMethod(method);
        setFormData({
            name: method.name || '',
            key: method.key || '',
            description: method.description || '',
            is_active: method.is_active ?? true,
            sort_order: method.sort_order || 0
        });
        setShowModal(true);
    };

    const handleDelete = async (row) => {
        const confirmed = await showConfirm(
            'Delete Payment Method',
            `Are you sure you want to delete ${row.name}?`
        );

        if (confirmed) {
            try {
                await axios.delete(`/api/admin/payment-methods/${row._id}`);
                showToast('success', 'Payment method deleted');
                fetchMethods();
            } catch (error) {
                showToast('error', error.response?.data?.message || 'Failed to delete payment method');
            }
        }
    };

    const handleStatusToggle = async (row, checked) => {
        try {
            await axios.put(`/api/admin/payment-methods/${row._id}`, {
                is_active: checked
            });
            showToast('success', 'Status updated successfully');
            fetchMethods();
        } catch (error) {
            showToast('error', 'Failed to update status');
        }
    };

    const columns = [
        {
            header: 'Method Name',
            accessor: 'name',
            render: (row) => (
                <div className="d-flex align-items-center gap-2">
                    <FaCreditCard className="text-secondary" />
                    <span className="fw-semibold">{row.name}</span>
                </div>
            )
        },
        {
            header: 'Key',
            accessor: 'key',
            render: (row) => <span className="text-muted font-monospace">{row.key}</span>
        },
        {
            header: 'Description',
            accessor: 'description',
            render: (row) => row.description || '—'
        },
        {
            header: 'Sort Order',
            accessor: 'sort_order',
            width: '100px'
        },
        {
            header: 'Status',
            accessor: 'is_active',
            render: (row) => (
                <Toggle
                    checked={row.is_active}
                    onChange={(checked) => handleStatusToggle(row, checked)}
                    label={row.is_active ? "Active" : "Inactive"}
                />
            )
        }
    ];

    const filteredData = methods.filter(m =>
        m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        m.key.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="admin-dashboard p-0">
            <Container fluid className="px-0">
                <Card className="main-content-card border-0 shadow-sm p-4">
                    <div className="dashboard-header mb-4">
                        <div>
                            <h2 className="dashboard-title">Payment Methods</h2>
                            <p className="text-muted small mb-0">Manage system payment gateways and options</p>
                        </div>
                        <Button variant="primary" className="btn-admin-action" onClick={() => {
                            setSelectedMethod(null);
                            setFormData({ name: '', key: '', description: '', is_active: true, sort_order: 0 });
                            setShowModal(true);
                        }}>
                            <FaPlus /> Add Method
                        </Button>
                    </div>

                    <div className="mb-4">
                        <InputGroup className="search-input-group" style={{ maxWidth: '400px' }}>
                            <InputGroup.Text className="bg-white border-end-0">
                                <FaSearch className="text-muted" />
                            </InputGroup.Text>
                            <Form.Control
                                placeholder="Search payment methods..."
                                className="border-start-0 ps-0"
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                            />
                        </InputGroup>
                    </div>

                    {loading ? (
                        <div className="text-center p-5"><Spinner animation="border" variant="primary" /></div>
                    ) : (
                        <Table
                            columns={columns}
                            data={filteredData}
                            actions={true}
                            onEdit={handleEdit}
                            onDelete={handleDelete}
                            pagination={true}
                            emptyMessage="No payment methods configured"
                        />
                    )}
                </Card>

                <Modal
                    show={showModal}
                    onHide={() => setShowModal(false)}
                    title={selectedMethod ? "Edit Payment Method" : "Add Payment Method"}
                    footer={
                        <>
                            <Button variant="outline-secondary" onClick={() => setShowModal(false)}>Cancel</Button>
                            <Button variant="primary" onClick={handleSave} disabled={saving}>
                                {saving ? <Spinner size="sm" /> : "Save Settings"}
                            </Button>
                        </>
                    }
                >
                    <Form>
                        <Row>
                            <Col md={6}>
                                <Form.Group className="mb-3">
                                    <Form.Label>Method Name</Form.Label>
                                    <Form.Control
                                        type="text"
                                        value={formData.name}
                                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                        placeholder="e.g. PayPal"
                                    />
                                </Form.Group>
                            </Col>
                            <Col md={6}>
                                <Form.Group className="mb-3">
                                    <Form.Label>Unique Key</Form.Label>
                                    <Form.Control
                                        type="text"
                                        value={formData.key}
                                        onChange={(e) => setFormData({ ...formData, key: e.target.value.toLowerCase().replace(/\s+/g, '_') })}
                                        placeholder="e.g. paypal"
                                        disabled={!!selectedMethod} // Usually shouldn't change key once set
                                    />
                                    {!selectedMethod && <Form.Text className="text-muted">Unique identifier, no spaces</Form.Text>}
                                </Form.Group>
                            </Col>
                        </Row>
                        <Form.Group className="mb-3">
                            <Form.Label>Description (Optional)</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={2}
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                placeholder="Instructions or internal notes..."
                            />
                        </Form.Group>
                        <Row>
                            <Col md={6}>
                                <Form.Group className="mb-3">
                                    <Form.Label>Sort Order</Form.Label>
                                    <Form.Control
                                        type="number"
                                        value={formData.sort_order}
                                        onChange={(e) => setFormData({ ...formData, sort_order: e.target.value })}
                                        min="0"
                                    />
                                    <Form.Text className="text-muted">Lower numbers appear first</Form.Text>
                                </Form.Group>
                            </Col>
                            <Col md={6} className="d-flex align-items-center">
                                <Form.Group className="mb-0 mt-3">
                                    <Form.Check
                                        type="switch"
                                        id="active-switch"
                                        label={formData.is_active ? "Method is Active" : "Method is Inactive"}
                                        checked={formData.is_active}
                                        onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                                    />
                                </Form.Group>
                            </Col>
                        </Row>
                    </Form>
                </Modal>
            </Container>
        </div>
    );
};

export default PaymentMethods;
