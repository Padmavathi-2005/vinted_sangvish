import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    FaSearch,
    FaBell,
    FaUser,
    FaCog,
    FaGlobe,
    FaCoins,
    FaSignOutAlt,
    FaChevronDown
} from 'react-icons/fa';
import { getAdminInfo, clearAdminInfo } from '../utils/auth';
import { useLocalization } from '../context/LocalizationContext';
import '../styles/AdminHeader.css';

const AdminHeader = () => {
    const navigate = useNavigate();
    const admin = getAdminInfo();
    const { language, currency, availableLanguages, availableCurrencies, changeLanguage, changeCurrency } = useLocalization();
    const [theme, setTheme] = useState(() => {
        return localStorage.getItem('adminTheme') || 'light';
    });

    // Dropdown search states
    const [langSearch, setLangSearch] = useState('');
    const [currSearch, setCurrSearch] = useState('');

    useEffect(() => {
        document.body.setAttribute('data-admin-theme', theme);
        localStorage.setItem('adminTheme', theme);
    }, [theme]);

    const handleLogout = () => {
        clearAdminInfo();
        navigate('/login');
    };

    const filteredLanguages = availableLanguages.filter(l =>
        l.name.toLowerCase().includes(langSearch.toLowerCase()) ||
        (l.native_name && l.native_name.toLowerCase().includes(langSearch.toLowerCase()))
    );

    const filteredCurrencies = availableCurrencies.filter(c =>
        c.name.toLowerCase().includes(currSearch.toLowerCase()) ||
        c.code.toLowerCase().includes(currSearch.toLowerCase())
    );

    return (
        <header className="admin-header">
            <div className="admin-header-content">
                {/* Search Section */}
                <div className="admin-search-section">
                    <div className="admin-search-wrapper">
                        <FaSearch className="search-icon" />
                        <input
                            type="text"
                            placeholder="Search users, listings, reports..."
                            className="admin-search-input"
                        />
                    </div>
                </div>

                {/* Right Section */}
                <div className="admin-header-right">
                    {/* Language Switcher */}
                    <div className="header-localization-dropdown">
                        <button className="header-action-btn select-box" title="Change Language">
                            <FaGlobe className="me-2 opacity-75" />
                            <span className="localization-label">{language.toUpperCase()}</span>
                            <FaChevronDown className="ms-auto opacity-50 chevron-icon" />
                        </button>
                        <div className="localization-menu">
                            <div className="dropdown-header">Select Language</div>
                            <div className="dropdown-search">
                                <FaSearch className="search-icon" />
                                <input
                                    type="text"
                                    placeholder="Search language..."
                                    value={langSearch}
                                    onChange={(e) => setLangSearch(e.target.value)}
                                    onClick={(e) => e.stopPropagation()}
                                />
                            </div>
                            <div className="dropdown-list scroll-area">
                                {filteredLanguages.length > 0 ? (
                                    filteredLanguages.map(lang => (
                                        <div
                                            key={lang.code}
                                            className={`localization-item ${language === lang.code ? 'active' : ''}`}
                                            onClick={() => { changeLanguage(lang.code); setLangSearch(''); }}
                                        >
                                            <div className="d-flex flex-column">
                                                <span className="item-name">{lang.name}</span>
                                                <span className="item-tag">{lang.native_name || lang.code.toUpperCase()}</span>
                                            </div>
                                            {language === lang.code && <div className="active-dot"></div>}
                                        </div>
                                    ))
                                ) : (
                                    <div className="no-results">No matches</div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Currency Switcher */}
                    <div className="header-localization-dropdown">
                        <button className="header-action-btn select-box" title="Change Currency">
                            <FaCoins className="me-2 opacity-75" />
                            <span className="localization-label">{currency}</span>
                            <FaChevronDown className="ms-auto opacity-50 chevron-icon" />
                        </button>
                        <div className="localization-menu">
                            <div className="dropdown-header">Select Currency</div>
                            <div className="dropdown-search">
                                <FaSearch className="search-icon" />
                                <input
                                    type="text"
                                    placeholder="Search currency..."
                                    value={currSearch}
                                    onChange={(e) => setCurrSearch(e.target.value)}
                                    onClick={(e) => e.stopPropagation()}
                                />
                            </div>
                            <div className="dropdown-list scroll-area">
                                {filteredCurrencies.length > 0 ? (
                                    filteredCurrencies.map(curr => (
                                        <div
                                            key={curr.code}
                                            className={`localization-item ${currency === curr.code ? 'active' : ''}`}
                                            onClick={() => { changeCurrency(curr.code); setCurrSearch(''); }}
                                        >
                                            <div className="d-flex flex-column">
                                                <span className="item-name">{curr.name}</span>
                                                <span className="item-tag">{curr.code} ({curr.symbol})</span>
                                            </div>
                                            {currency === curr.code && <div className="active-dot"></div>}
                                        </div>
                                    ))
                                ) : (
                                    <div className="no-results">No matches</div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Settings */}
                    <button className="header-action-btn" title="Settings" onClick={() => navigate('/settings/general_settings')}>
                        <FaCog />
                    </button>

                    {/* Notifications */}
                    <button className="header-action-btn notification-btn" title="Notifications">
                        <FaBell />
                        <span className="notification-badge">3</span>
                    </button>

                    {/* Unified Profile & Logout Box */}
                    <div className="header-profile-box">
                        <div className="profile-section">
                            <div className="admin-avatar-circle">
                                <FaUser />
                            </div>
                            <span className="admin-name">{admin?.name || 'Main Admin'}</span>
                        </div>
                        <div className="divider-line"></div>
                        <button className="logout-icon-btn" onClick={handleLogout} title="Logout">
                            <FaSignOutAlt />
                        </button>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default AdminHeader;
