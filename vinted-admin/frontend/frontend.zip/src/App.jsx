import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import AdminLayout from './components/AdminLayout';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import Reports from './pages/Reports';
import Users from './pages/Users';
import Listings from './pages/Listings';
import Orders from './pages/Orders';
import DynamicSettings from './pages/DynamicSettings';
import Categories from './pages/Categories';
import Subcategories from './pages/Subcategories';
import ItemTypes from './pages/ItemTypes';
import Languages from './pages/Languages';
import Currencies from './pages/Currencies';
import Transactions from './pages/Transactions';
import PaymentMethods from './pages/PaymentMethods';
import WithdrawalRequests from './pages/WithdrawalRequests';
import Pages from './pages/Pages';
import PageEditor from './pages/PageEditor';
import NotFound from './pages/NotFound';

function App() {
    return (
        <Router>
            <AdminLayout>
                <Routes>
                    <Route path="/" element={<Navigate to="/dashboard" />} />
                    <Route path="/login" element={<AdminLogin />} />
                    <Route path="/dashboard" element={<AdminDashboard />} />
                    <Route path="/reports" element={<Reports />} />
                    <Route path="/users" element={<Users />} />
                    <Route path="/listings" element={<Listings />} />
                    <Route path="/orders" element={<Orders />} />
                    <Route path="/wallet/transactions" element={<Transactions />} />
                    <Route path="/wallet/payment-methods" element={<PaymentMethods />} />
                    <Route path="/wallet/withdrawal-requests" element={<WithdrawalRequests />} />
                    <Route path="/categories/main" element={<Categories />} />
                    <Route path="/categories/subcategories" element={<Subcategories />} />
                    <Route path="/categories/item-types" element={<ItemTypes />} />
                    <Route path="/settings/languages" element={<Languages />} />
                    <Route path="/settings/currencies" element={<Currencies />} />
                    <Route path="/settings/:type" element={<DynamicSettings />} />
                    <Route path="/pages" element={<Pages />} />
                    <Route path="/pages/new" element={<PageEditor />} />
                    <Route path="/pages/edit/:id" element={<PageEditor />} />
                    {/* fallback */}
                    <Route path="/settings" element={<Navigate to="/settings/general_settings" />} />
                    <Route path="*" element={<NotFound />} />
                </Routes>
            </AdminLayout>
        </Router>
    );
}

export default App;
