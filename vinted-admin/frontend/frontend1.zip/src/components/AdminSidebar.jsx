import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import axios from '../utils/axios';
import {
    FaTachometerAlt,
    FaUsers,
    FaUser,
    FaShoppingBag,
    FaBoxOpen,
    FaCog,
    FaChartBar,
    FaTags,
    FaBars,
    FaTimes,
    FaChevronLeft,
    FaChevronRight,
    FaCogs,
    FaAngleDown,
    FaAngleRight,
    FaGlobe,
    FaMoneyBillWave,
    FaWallet,
    FaFileAlt,
    FaLanguage,
    FaEnvelope
} from 'react-icons/fa';
import { getAdminInfo } from '../utils/auth';
import { useSettings } from '../context/SettingsContext';
import { useLocalization } from '../context/LocalizationContext';
import '../styles/AdminSidebar.css';

const AdminSidebar = () => {
    const { t } = useLocalization();
    const location = useLocation();
    const admin = getAdminInfo();
    const [isCollapsed, setIsCollapsed] = useState(() => {
        const isMobile = window.innerWidth < 992;
        return isMobile ? true : (localStorage.getItem('sidebarCollapsed') === 'true');
    });
    const isMobile = window.innerWidth < 992;

    const [isHovered, setIsHovered] = useState(false);
    const { settingTypes, siteName, siteLogo } = useSettings();

    // State for expanded submenus
    const [expandedMenus, setExpandedMenus] = useState({
        settings: true // Default expanded
    });

    const menuItems = [
        { path: '/dashboard', icon: <FaTachometerAlt />, label: t('sidebar.dashboard') },
        { path: '/users', icon: <FaUsers />, label: t('sidebar.users') },
        { path: '/listings', icon: <FaShoppingBag />, label: t('sidebar.listings') },
        { path: '/orders', icon: <FaBoxOpen />, label: t('sidebar.orders') },
        {
            id: 'wallet',
            path: '/wallet',
            icon: <FaWallet />,
            label: t('sidebar.wallet.title'),
            subItems: [
                { path: '/wallet/withdrawal-requests', label: t('sidebar.wallet.withdrawal_requests'), icon: <FaMoneyBillWave size={12} /> },
                { path: '/wallet/transactions', label: t('sidebar.wallet.transactions'), icon: <FaWallet size={12} /> }
            ]
        },
        { path: '/categories/main', icon: <FaTags />, label: t('sidebar.categories.title') },
        { path: '/newsletter', icon: <FaEnvelope />, label: 'Newsletter' },
        { path: '/pages', icon: <FaFileAlt />, label: 'Static Pages' },
        { path: '/reports', icon: <FaChartBar />, label: t('sidebar.reports') },
        {
            id: 'settings',
            path: '/settings',
            icon: <FaCog />,
            label: t('sidebar.settings.title'),
            subItems: [
                ...settingTypes.map(type => {
                    const labelKey = `sidebar.settings.${type}`;
                    const translatedLabel = t(labelKey);

                    return {
                        path: `/settings/${type}`,
                        label: translatedLabel === labelKey
                            ? type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())
                            : translatedLabel,
                        icon: <FaCogs size={12} />
                    };
                }),
                { path: '/frontend/content', label: 'Frontend Content', icon: <FaLanguage size={12} /> },
                { path: '/settings/payment-methods', label: 'Payment Methods', icon: <FaMoneyBillWave size={12} /> },
            ]
        },
        { path: '/settings/languages', label: t('sidebar.settings.languages'), icon: <FaGlobe /> },
        { path: '/settings/currencies', label: t('sidebar.settings.currencies'), icon: <FaMoneyBillWave /> },
    ];

    useEffect(() => {
        const handleResize = () => {
            const isMobileView = window.innerWidth < 992;
            if (isMobileView) {
                setIsCollapsed(true);
            }
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const toggleSidebar = () => {
        const newCollapsedState = !isCollapsed;
        setIsCollapsed(newCollapsedState);
        if (window.innerWidth >= 992) {
            localStorage.setItem('sidebarCollapsed', newCollapsedState.toString());
        }
    };

    const toggleSubMenu = (menuId) => {
        if (isCollapsed && !isHovered) return; // Don't toggle in fully collapsed mode
        setExpandedMenus(prev => {
            if (prev[menuId]) {
                return {}; // Close if it's already open
            }
            return { [menuId]: true }; // Open new one, close all others
        });
    };

    const trulyCollapsed = isCollapsed && !isHovered;

    return (
        <>
            {isMobile && !isCollapsed && (
                <div className="sidebar-overlay" onClick={toggleSidebar}></div>
            )}

            <aside
                className={`admin-sidebar ${trulyCollapsed ? 'collapsed' : ''} ${isHovered ? 'hover-expanded' : ''}`}
                onMouseEnter={() => { if (isCollapsed && !isMobile) setIsHovered(true); }}
                onMouseLeave={() => { setIsHovered(false); }}
            >
                <div className="sidebar-header">
                    {!trulyCollapsed && (
                        <div className="sidebar-logo">
                            {siteLogo ? (
                                <img src={`${axios.defaults.baseURL}/${siteLogo}`} alt="Site Logo" className="logo-img" />
                            ) : (
                                <>
                                    <div className="logo-icon"><span>{(siteName || 'A').charAt(0)}</span></div>
                                    <span className="logo-text">{siteName || 'Admin Panel'}</span>
                                </>
                            )}
                        </div>
                    )}
                    <button className={`collapse-btn ${trulyCollapsed ? 'is-collapsed' : ''}`} onClick={toggleSidebar} title={trulyCollapsed ? "Expand" : "Collapse"}>
                        {trulyCollapsed ? <FaChevronRight /> : <FaChevronLeft />}
                    </button>
                </div>

                <nav className="sidebar-nav">
                    {menuItems.map((item) => {
                        if (item.subItems) {
                            const isExpanded = expandedMenus[item.id];
                            const isActive = location.pathname.startsWith(item.path);

                            return (
                                <div key={item.id} className="nav-group">
                                    <div
                                        className={`nav-link ${isActive ? 'active-parent' : ''} ${trulyCollapsed ? 'collapsed-link' : ''}`}
                                        onClick={() => !trulyCollapsed && toggleSubMenu(item.id)}
                                        title={trulyCollapsed ? item.label : ''}
                                        style={{ cursor: 'pointer', justifyContent: trulyCollapsed ? 'center' : 'space-between' }}
                                    >
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                                            <span className="nav-icon">{item.icon}</span>
                                            {!trulyCollapsed && <span className="nav-label">{item.label}</span>}
                                        </div>
                                        {!trulyCollapsed && (
                                            <span style={{ fontSize: '0.8rem', opacity: 0.7 }}>
                                                {isExpanded ? <FaAngleDown /> : <FaAngleRight />}
                                            </span>
                                        )}
                                    </div>

                                    {/* Submenu */}
                                    {!trulyCollapsed && (
                                        <div className={`sub-menu-wrapper ${isExpanded ? 'expanded' : ''}`}>
                                            <div className="sub-menu-inner">
                                                <div className="sub-menu">
                                                    {item.subItems.map(subItem => (
                                                        <Link
                                                            key={subItem.path}
                                                            to={subItem.path}
                                                            className={`nav-link sub-link ${location.pathname === subItem.path ? 'active' : ''}`}
                                                            onClick={() => isMobile && setIsCollapsed(true)}
                                                            title={subItem.label}
                                                        >
                                                            <span className="nav-icon" style={{ fontSize: '0.9rem', opacity: 0.5, fontWeight: 'bold' }}>
                                                                -
                                                            </span>
                                                            <span className="nav-label" style={{
                                                                fontSize: '0.82rem',
                                                                display: 'block'
                                                            }}>{subItem.label}</span>
                                                        </Link>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            );
                        }

                        return (
                            <Link
                                key={item.path}
                                to={item.path}
                                className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
                                onClick={() => isMobile && setIsCollapsed(true)}
                                title={trulyCollapsed ? item.label : ''}
                            >
                                <span className="nav-icon">{item.icon}</span>
                                {!trulyCollapsed && <span className="nav-label">{item.label}</span>}
                            </Link>
                        );
                    })}
                </nav>


            </aside>
        </>
    );
};

export default AdminSidebar;
