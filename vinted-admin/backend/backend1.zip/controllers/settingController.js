import asyncHandler from 'express-async-handler';
import Setting from '../models/Setting.js';



// @desc    Get all unique setting types
// @route   GET /api/settings/types
// @access  Private (Admin)
const getSettingTypes = asyncHandler(async (req, res) => {
    const types = await Setting.distinct('type');
    res.json(types);
});

// @desc    Get settings by type
// @route   GET /api/settings/:type
// @access  Public (some might be private)
const getSettingsByType = asyncHandler(async (req, res) => {
    const { type } = req.params;
    let setting = await Setting.findOne({ type });

    if (!setting && type === 'general_settings') {
        setting = await Setting.create({
            type: 'general_settings',
            primary_color: '#0ea5e9',
            secondary_color: '#1e293b',
            pagination_limit: 12,
            pagination_mode: 'paginate',
            maintenance_mode: false,
            allow_registration: true,
            allow_guest_checkout: false,
            timezone: 'UTC',
            admin_commission: 2
        });
    }

    if (!setting && type === 'site_settings') {
        setting = await Setting.create({
            type: 'site_settings',
            site_name: 'My Marketplace',
        });
    }

    // fallback for legacy admin_settings mapping
    if (!setting && type === 'social_login_settings') {
        setting = await Setting.create({
            type: 'social_login_settings',
            google_enabled: false,
            google_client_id: '',
            google_client_secret: '',
            facebook_enabled: false,
            facebook_client_id: '',
            facebook_client_secret: '',
            twitter_enabled: false,
            twitter_client_id: '',
            twitter_client_secret: '',
            apple_enabled: false,
            apple_client_id: '',
            apple_client_secret: '',
        });
    }

    if (type === 'admin_settings' && !setting) {
        setting = await Setting.findOne({ type: 'general_settings' });
    }

    if (setting) {
        res.json(setting);
    } else {
        res.status(404).json({ message: 'Settings not found' });
    }
});

// @desc    Update settings by type
// @route   PUT /api/settings/:type
// @access  Private (Admin)
const updateSettingsByType = asyncHandler(async (req, res) => {
    const { type } = req.params;
    console.log(`\n[SETTINGS UPDATE] Type: ${type}`);
    console.log('[BODY]:', req.body);

    let setting = await Setting.findOne({ type });

    const updateData = { ...req.body };

    // Explicitly delete problematic or metadata fields
    const blacklist = ['_id', '__v', 'created_at', 'updated_at', 'type', 'general_settings'];
    blacklist.forEach(field => delete updateData[field]);

    // Handle file uploads specifically
    if (req.files) {
        if (req.files.site_logo) {
            updateData.site_logo = `images/site/${req.files.site_logo[0].filename}`;
            console.log('-> New Site Logo:', updateData.site_logo);
        }
        if (req.files.site_favicon) {
            updateData.site_favicon = `images/site/${req.files.site_favicon[0].filename}`;
            console.log('-> New Site Favicon:', updateData.site_favicon);
        }
        if (req.files.image_not_found) {
            updateData.image_not_found = `images/site/${req.files.image_not_found[0].filename}`;
            console.log('-> New Image Not Found:', updateData.image_not_found);
        }
        if (req.files.empty_table_image) {
            updateData.empty_table_image = `images/site/${req.files.empty_table_image[0].filename}`;
            console.log('-> New Empty Table Image:', updateData.empty_table_image);
        }
    }

    if (setting) {
        console.log('-> Found existing settings. Merging updates...');
        Object.keys(updateData).forEach(key => {
            // Only update if value is provided and valid
            if (updateData[key] !== undefined && updateData[key] !== 'undefined' && updateData[key] !== null) {
                let finalVal = updateData[key];

                // Convert string "true" / "false" back to booleans
                if (finalVal === 'true') finalVal = true;
                if (finalVal === 'false') finalVal = false;

                console.log(`   Setting ${key} = ${finalVal}`);
                setting.set(key, finalVal);
            }
        });

        try {
            const updatedSetting = await setting.save();
            console.log(`[SUCCESS] Saved ${type}. New primary_color: ${updatedSetting.primary_color}`);
            res.json(updatedSetting);
        } catch (saveErr) {
            console.error('[ERROR] Save failed:', saveErr.message);
            res.status(500).json({ message: 'Database save failed', error: saveErr.message });
        }
    } else {
        console.log(`-> No settings found for ${type}. Creating new...`);
        const newSetting = await Setting.create({ ...updateData, type });
        console.log(`[SUCCESS] Created ${type}. Primary_color: ${newSetting.primary_color}`);
        res.status(201).json(newSetting);
    }
});

export {
    getSettingTypes,
    getSettingsByType,
    updateSettingsByType,
};
